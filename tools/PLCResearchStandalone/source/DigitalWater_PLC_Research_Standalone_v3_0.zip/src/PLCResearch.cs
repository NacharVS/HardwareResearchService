﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;

namespace DigitalWater.PlcResearchStandalone
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            ComSecurity.InitializeProcessSecurity();

            AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs args)
            {
                try
                {
                    string name = new System.Reflection.AssemblyName(args.Name).Name + ".dll";
                    string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, name);
                    if (File.Exists(path))
                    {
                        return System.Reflection.Assembly.LoadFrom(path);
                    }
                }
                catch
                {
                }

                return null;
            };

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    internal sealed class MainForm : Form
    {
        private readonly ComboBox _protocol;
        private readonly Label _endpointLabel;
        private readonly TextBox _endpoint;

        private readonly Label _daServerLabel;
        private readonly ComboBox _daServer;
        private readonly Button _findDaServers;
        private readonly Label _daIdentityNote;

        private readonly Label _securityLabel;
        private readonly ComboBox _security;
        private readonly CheckBox _anonymous;
        private readonly Label _usernameLabel;
        private readonly TextBox _username;
        private readonly Label _passwordLabel;
        private readonly TextBox _password;

        private readonly CheckBox _readValues;
        private readonly TextBox _output;
        private readonly Button _browseOutput;
        private readonly Button _run;
        private readonly Button _cancel;
        private readonly ProgressBar _progress;
        private readonly Label _stage;
        private readonly Label _stats;
        private readonly TextBox _log;

        private CancellationTokenSource _cts;

        public MainForm()
        {
            Text = "DigitalWater — автономное исследование PLC v3.0";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(930, 790);
            MinimumSize = new Size(930, 790);
            Font = new Font("Segoe UI", 10F);

            Label title = new Label();
            title.Text = "Автономное исследование PLC — OPC UA / OPC DA";
            title.Font = new Font("Segoe UI Semibold", 17F);
            title.Location = new Point(24, 18);
            title.Size = new Size(850, 38);
            Controls.Add(title);

            Label intro = new Label();
            intro.Text =
                "Прямое подключение без LocalApp и GlobalHub. " +
                "OPC UA — напрямую к UA endpoint; OPC DA — через Windows COM/DCOM к OPC DA Server.";
            intro.Location = new Point(26, 58);
            intro.Size = new Size(850, 45);
            Controls.Add(intro);

            AddLabel("Протокол", 24, 111, 210);
            _protocol = new ComboBox();
            _protocol.DropDownStyle = ComboBoxStyle.DropDownList;
            _protocol.Items.Add("OPC UA");
            _protocol.Items.Add("OPC DA (Classic COM/DCOM)");
            _protocol.SelectedIndex = 0;
            _protocol.Location = new Point(245, 108);
            _protocol.Size = new Size(350, 28);
            _protocol.SelectedIndexChanged += delegate { UpdateProtocolUi(); };
            Controls.Add(_protocol);

            _endpointLabel = AddLabel("IP / OPC UA endpoint", 24, 151, 210);
            _endpoint = new TextBox();
            _endpoint.Location = new Point(245, 148);
            _endpoint.Size = new Size(625, 27);
            Controls.Add(_endpoint);

            _daServerLabel = AddLabel("OPC DA Server", 24, 190, 210);
            _daServer = new ComboBox();
            _daServer.DropDownStyle = ComboBoxStyle.DropDown;
            _daServer.Location = new Point(245, 187);
            _daServer.Size = new Size(480, 28);
            Controls.Add(_daServer);

            _findDaServers = new Button();
            _findDaServers.Text = "Найти DA-серверы";
            _findDaServers.Location = new Point(735, 185);
            _findDaServers.Size = new Size(135, 32);
            _findDaServers.Click += FindDaServers;
            Controls.Add(_findDaServers);

            _daIdentityNote = new Label();
            _daIdentityNote.Text =
                "OPC DA использует текущую Windows-учётную запись. " +
                "Для удалённого сервера должны быть настроены OPCEnum/DCOM и firewall.";
            _daIdentityNote.Location = new Point(245, 220);
            _daIdentityNote.Size = new Size(625, 42);
            Controls.Add(_daIdentityNote);

            _securityLabel = AddLabel("Режим безопасности", 24, 229, 210);
            _security = new ComboBox();
            _security.DropDownStyle = ComboBoxStyle.DropDownList;
            _security.Items.Add("Авто: сначала защищённый, затем None");
            _security.Items.Add("Только защищённый endpoint");
            _security.Items.Add("Только SecurityPolicy=None");
            _security.SelectedIndex = 0;
            _security.Location = new Point(245, 226);
            _security.Size = new Size(355, 28);
            Controls.Add(_security);

            _anonymous = new CheckBox();
            _anonymous.Text = "Анонимное подключение";
            _anonymous.Checked = true;
            _anonymous.Location = new Point(615, 227);
            _anonymous.Size = new Size(255, 28);
            _anonymous.CheckedChanged += delegate { UpdateCredentialsState(); };
            Controls.Add(_anonymous);

            _usernameLabel = AddLabel("Пользователь", 24, 268, 210);
            _username = new TextBox();
            _username.Location = new Point(245, 265);
            _username.Size = new Size(245, 27);
            Controls.Add(_username);

            _passwordLabel = AddLabel("Пароль", 510, 268, 70);
            _password = new TextBox();
            _password.Location = new Point(580, 265);
            _password.Size = new Size(290, 27);
            _password.UseSystemPasswordChar = true;
            Controls.Add(_password);

            _readValues = new CheckBox();
            _readValues.Text = "Дополнительно прочитать текущие значения";
            _readValues.Checked = true;
            _readValues.Location = new Point(245, 305);
            _readValues.Size = new Size(480, 28);
            Controls.Add(_readValues);

            AddLabel("Сохранить JSON в", 24, 348, 210);
            _output = new TextBox();
            _output.Location = new Point(245, 345);
            _output.Size = new Size(485, 27);
            _output.Text = GetDefaultOutputDirectory();
            Controls.Add(_output);

            _browseOutput = new Button();
            _browseOutput.Text = "Выбрать...";
            _browseOutput.Location = new Point(740, 343);
            _browseOutput.Size = new Size(130, 31);
            _browseOutput.Click += BrowseOutput;
            Controls.Add(_browseOutput);

            _run = new Button();
            _run.Text = "Исследовать и сохранить JSON";
            _run.Location = new Point(24, 397);
            _run.Size = new Size(350, 44);
            _run.Click += RunResearch;
            Controls.Add(_run);

            _cancel = new Button();
            _cancel.Text = "Остановить";
            _cancel.Location = new Point(389, 397);
            _cancel.Size = new Size(150, 44);
            _cancel.Enabled = false;
            _cancel.Click += delegate
            {
                if (_cts != null)
                {
                    _cts.Cancel();
                }
            };
            Controls.Add(_cancel);

            Label readOnly = new Label();
            readOnly.Text =
                "READ ONLY: UA — Browse/Read; DA — Browse/чтение свойств. " +
                "В утилите отсутствуют Write и управляющие команды.";
            readOnly.ForeColor = Color.DarkGreen;
            readOnly.Location = new Point(24, 454);
            readOnly.Size = new Size(850, 30);
            Controls.Add(readOnly);

            _stage = new Label();
            _stage.Text = "Готово к запуску";
            _stage.Font = new Font("Segoe UI Semibold", 10F);
            _stage.Location = new Point(24, 495);
            _stage.Size = new Size(850, 25);
            Controls.Add(_stage);

            _progress = new ProgressBar();
            _progress.Location = new Point(24, 524);
            _progress.Size = new Size(846, 18);
            _progress.Style = ProgressBarStyle.Continuous;
            Controls.Add(_progress);

            _stats = new Label();
            _stats.Location = new Point(24, 551);
            _stats.Size = new Size(846, 28);
            Controls.Add(_stats);

            _log = new TextBox();
            _log.Location = new Point(24, 588);
            _log.Size = new Size(846, 130);
            _log.Multiline = true;
            _log.ReadOnly = true;
            _log.ScrollBars = ScrollBars.Vertical;
            _log.Font = new Font("Consolas", 9F);
            Controls.Add(_log);

            UpdateProtocolUi();

            Log("Приложение готово.");
            Log("OPC UA: введите IP/endpoint. OPC DA: введите Windows-хост и выберите/введите ProgID или CLSID.");
        }

        private Label AddLabel(string text, int x, int y, int width)
        {
            Label label = new Label();
            label.Text = text;
            label.Location = new Point(x, y);
            label.Size = new Size(width, 25);
            Controls.Add(label);
            return label;
        }

        private bool IsDaMode
        {
            get { return _protocol.SelectedIndex == 1; }
        }

        private void UpdateProtocolUi()
        {
            bool da = IsDaMode;

            _endpointLabel.Text = da
                ? "Windows-хост / IP OPC DA"
                : "IP / OPC UA endpoint";

            _daServerLabel.Visible = da;
            _daServer.Visible = da;
            _findDaServers.Visible = da;
            _daIdentityNote.Visible = da;

            _securityLabel.Visible = !da;
            _security.Visible = !da;
            _anonymous.Visible = !da;
            _usernameLabel.Visible = !da;
            _username.Visible = !da;
            _passwordLabel.Visible = !da;
            _password.Visible = !da;

            if (da)
            {
                _readValues.Text = "Дополнительно прочитать Value / Quality / Timestamp";
                _run.Text = "Исследовать OPC DA и сохранить JSON";
            }
            else
            {
                _readValues.Text = "Дополнительно прочитать текущие значения";
                _run.Text = "Исследовать OPC UA и сохранить JSON";
            }

            UpdateCredentialsState();
        }

        private static string GetDefaultOutputDirectory()
        {
            string downloads = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");

            if (Directory.Exists(downloads))
            {
                return downloads;
            }

            return Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        }

        private void UpdateCredentialsState()
        {
            bool enabled = !IsDaMode && !_anonymous.Checked && _run.Enabled;
            _username.Enabled = enabled;
            _password.Enabled = enabled;
        }

        private void BrowseOutput(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (Directory.Exists(_output.Text))
                {
                    dialog.SelectedPath = _output.Text;
                }

                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    _output.Text = dialog.SelectedPath;
                }
            }
        }

        private async void FindDaServers(object sender, EventArgs e)
        {
            string host = _endpoint.Text.Trim();
            if (host.Length == 0)
            {
                MessageBox.Show(
                    this,
                    "Введите IP или имя Windows-компьютера, на котором работает OPC DA Server.",
                    "Хост не указан",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (host.IndexOf("://", StringComparison.Ordinal) >= 0)
            {
                MessageBox.Show(
                    this,
                    "Для OPC DA здесь нужен IP/hostname Windows-компьютера, а не opc.tcp:// адрес.",
                    "Неверный адрес",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            _findDaServers.Enabled = false;
            _stage.Text = "Поиск OPC DA Server через OPCEnum";
            _progress.Style = ProgressBarStyle.Marquee;

            try
            {
                Log("OPC DA: поиск серверов на " + host + " через OPCEnum.");

                List<DaServerInfo> servers = await Task.Run(
                    delegate
                    {
                        return OpcDaScanner.DiscoverServers(host, CancellationToken.None, LogThreadSafe);
                    });

                _daServer.Items.Clear();
                foreach (DaServerInfo server in servers)
                {
                    _daServer.Items.Add(server);
                }

                if (_daServer.Items.Count > 0)
                {
                    _daServer.SelectedIndex = 0;
                }

                _stage.Text = "Найдено OPC DA Server: " + servers.Count;
                _progress.Style = ProgressBarStyle.Continuous;
                _progress.Value = 0;

                Log("OPC DA: найдено серверов: " + servers.Count + ".");

                if (servers.Count == 0)
                {
                    MessageBox.Show(
                        this,
                        "OPCEnum ответил, но DA-серверы не найдены.\r\n" +
                        "Можно вручную ввести ProgID или CLSID в поле «OPC DA Server».",
                        "DA-серверы не найдены",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                _stage.Text = "Не удалось получить список OPC DA Server";
                _progress.Style = ProgressBarStyle.Continuous;
                _progress.Value = 0;
                Log("OPC DA discovery ERROR: " + ex);

                MessageBox.Show(
                    this,
                    "Не удалось получить список через OPCEnum:\r\n\r\n" +
                    ex.Message +
                    "\r\n\r\nЕсли ProgID/CLSID сервера известен, его можно ввести вручную.",
                    "Ошибка OPC DA / DCOM",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                _findDaServers.Enabled = true;
            }
        }

        private async void RunResearch(object sender, EventArgs e)
        {
            string endpoint = _endpoint.Text.Trim();
            if (endpoint.Length == 0)
            {
                MessageBox.Show(
                    this,
                    IsDaMode
                        ? "Введите IP или имя Windows-хоста OPC DA Server."
                        : "Введите IP или OPC UA endpoint.",
                    "Адрес не указан",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (IsDaMode && endpoint.IndexOf("://", StringComparison.Ordinal) >= 0)
            {
                MessageBox.Show(
                    this,
                    "В режиме OPC DA вводится IP/hostname Windows-компьютера. " +
                    "Адрес opc.tcp:// относится к OPC UA.",
                    "Неверный адрес OPC DA",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            string outputDir = _output.Text.Trim();
            if (outputDir.Length == 0)
            {
                MessageBox.Show(
                    this,
                    "Укажите папку для JSON.",
                    "Папка не указана",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            Directory.CreateDirectory(outputDir);

            ToggleBusy(true);
            _progress.Style = ProgressBarStyle.Marquee;
            _progress.Value = 0;
            _stage.Text = "Подготовка";
            _stats.Text = "";
            _cts = new CancellationTokenSource();

            Progress<ScanProgress> progress = new Progress<ScanProgress>(
                delegate(ScanProgress p)
                {
                    UpdateProgress(p);
                });

            try
            {
                ResearchResult result;

                if (IsDaMode)
                {
                    string serverToken = _daServer.Text.Trim();
                    DaServerInfo selected = _daServer.SelectedItem as DaServerInfo;

                    if (serverToken.Length == 0 && selected == null)
                    {
                        throw new InvalidOperationException(
                            "Сначала выберите найденный OPC DA Server или вручную укажите его ProgID/CLSID.");
                    }

                    DaScanOptions options = new DaScanOptions();
                    options.Host = endpoint;
                    options.ServerToken =
                        selected != null && !String.IsNullOrWhiteSpace(selected.ProgId)
                            ? selected.ProgId
                            : serverToken;
                    options.Clsid = selected == null ? null : (Guid?)selected.Clsid;
                    options.KnownVersions = selected == null
                        ? new List<string>()
                        : new List<string>(selected.Versions);
                    options.ServerUserType = selected == null ? null : selected.UserType;
                    options.ReadCurrentValues = _readValues.Checked;

                    Log(
                        "Начинаю прямое OPC DA исследование: host=" +
                        options.Host +
                        ", server=" +
                        options.ServerToken);

                    OpcDaScanner scanner = new OpcDaScanner();
                    result = await Task.Run(
                        delegate
                        {
                            return scanner.Scan(
                                options,
                                progress,
                                _cts.Token,
                                LogThreadSafe);
                        });
                }
                else
                {
                    ScanOptions options = new ScanOptions();
                    options.Endpoint = endpoint;
                    options.SecurityMode = _security.SelectedIndex;
                    options.Anonymous = _anonymous.Checked;
                    options.Username = _username.Text.Trim();
                    options.Password = _password.Text;
                    options.ReadCurrentValues = _readValues.Checked;
                    options.PkiDirectory = Path.Combine(
                        AppDomain.CurrentDomain.BaseDirectory,
                        "pki");

                    Log("Начинаю прямое OPC UA исследование: " + endpoint);

                    OpcUaScanner scanner = new OpcUaScanner();
                    result = await Task.Run(
                        delegate
                        {
                            return scanner.Scan(
                                options,
                                progress,
                                _cts.Token,
                                LogThreadSafe);
                        });
                }

                string token = SafeFileToken(
                    result.Protocol == "OPC_DA"
                        ? result.Host + "_" + result.ProgId
                        : result.EndpointUrl);

                string fileName =
                    "DigitalWater_PLC_Research_" +
                    result.Protocol +
                    "_" +
                    token +
                    "_" +
                    DateTime.Now.ToString(
                        "yyyyMMdd_HHmmss",
                        CultureInfo.InvariantCulture) +
                    ".json";

                string path = Path.Combine(outputDir, fileName);
                string json = JsonConvert.SerializeObject(
                    result,
                    Formatting.Indented);

                File.WriteAllText(
                    path,
                    json,
                    new UTF8Encoding(false));

                _stage.Text = "Исследование завершено";
                _progress.Style = ProgressBarStyle.Continuous;
                _progress.Value = 100;

                _stats.Text =
                    (result.Protocol == "OPC_DA"
                        ? "Найдено DA Item: "
                        : "Найдено переменных: ") +
                    result.VariableCount +
                    " · просмотрено: " +
                    result.BrowsedNodeCount +
                    (result.Truncated
                        ? " · достигнут лимит"
                        : "");

                Log("JSON сохранён: " + path);

                MessageBox.Show(
                    this,
                    "Готово.\r\n\r\n" + path,
                    "PLC исследован",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                try
                {
                    System.Diagnostics.Process.Start(
                        "explorer.exe",
                        "/select,\"" + path + "\"");
                }
                catch
                {
                }
            }
            catch (OperationCanceledException)
            {
                _stage.Text = "Остановлено пользователем";
                _progress.Style = ProgressBarStyle.Continuous;
                _progress.Value = 0;
                Log("Исследование остановлено.");
            }
            catch (Exception ex)
            {
                _stage.Text = "Ошибка";
                _progress.Style = ProgressBarStyle.Continuous;
                _progress.Value = 0;
                _stats.Text = ex.Message;
                Log("ОШИБКА: " + ex);

                MessageBox.Show(
                    this,
                    ex.Message,
                    "Ошибка исследования PLC",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                if (_cts != null)
                {
                    _cts.Dispose();
                    _cts = null;
                }

                ToggleBusy(false);
            }
        }

        private void ToggleBusy(bool busy)
        {
            _run.Enabled = !busy;
            _cancel.Enabled = busy;
            _protocol.Enabled = !busy;
            _endpoint.Enabled = !busy;
            _daServer.Enabled = !busy;
            _findDaServers.Enabled = !busy;
            _security.Enabled = !busy;
            _anonymous.Enabled = !busy;
            _readValues.Enabled = !busy;
            _output.Enabled = !busy;
            _browseOutput.Enabled = !busy;

            UpdateCredentialsState();
        }

        private void UpdateProgress(ScanProgress p)
        {
            _stage.Text = p.Stage;
            _stats.Text = p.Details;

            if (p.Percent.HasValue)
            {
                _progress.Style = ProgressBarStyle.Continuous;
                int value = Math.Max(0, Math.Min(100, p.Percent.Value));
                _progress.Value = value;
            }
            else
            {
                _progress.Style = ProgressBarStyle.Marquee;
            }
        }

        private void Log(string text)
        {
            _log.AppendText(
                "[" +
                DateTime.Now.ToString("HH:mm:ss") +
                "] " +
                text +
                "\r\n");

            _log.SelectionStart = _log.Text.Length;
            _log.ScrollToCaret();
        }

        private void LogThreadSafe(string text)
        {
            if (IsDisposed)
            {
                return;
            }

            BeginInvoke((Action)delegate { Log(text); });
        }

        private static string SafeFileToken(string value)
        {
            if (String.IsNullOrWhiteSpace(value))
            {
                return "PLC";
            }

            StringBuilder builder = new StringBuilder();

            foreach (char c in value)
            {
                if (Char.IsLetterOrDigit(c) ||
                    c == '-' ||
                    c == '_' ||
                    c == '.')
                {
                    builder.Append(c);
                }
                else
                {
                    builder.Append('_');
                }
            }

            string token = builder.ToString().Trim('_');
            return token.Length == 0 ? "PLC" : token;
        }
    }

    internal sealed class OpcUaScanner
    {
        private const int MaxNodes = 50000;
        private const int MaxDepth = 64;
        private const int BrowseBatchSize = 100;
        private const int MetadataBatchSize = 100;

        public ResearchResult Scan(
            ScanOptions options,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            DateTimeOffset started = DateTimeOffset.UtcNow;
            string endpointUrl = NormalizeEndpoint(options.Endpoint);

            Report(progress, "Подключение к PLC",
                "Endpoint: " + endpointUrl, null);

            ApplicationConfiguration config = CreateConfiguration(
                options.PkiDirectory);

            ApplicationInstance application = new ApplicationInstance(config);
            application.ApplicationName = config.ApplicationName;
            application.ApplicationType = ApplicationType.Client;

            bool certificateOk;

            try
            {
                certificateOk = application
                    .CheckApplicationInstanceCertificatesAsync(
                        true,
                        (ushort?)120,
                        ct)
                    .GetAwaiter()
                    .GetResult();
            }
            catch (ServiceResultException ex)
            {
                string ownDirectory = Path.Combine(
                    options.PkiDirectory,
                    "own");

                bool looksLikeOwnCertificateProblem =
                    ex.Message.IndexOf(
                        "certificate",
                        StringComparison.OrdinalIgnoreCase) >= 0 &&
                    ex.Message.IndexOf(
                        "configuration",
                        StringComparison.OrdinalIgnoreCase) >= 0;

                if (!looksLikeOwnCertificateProblem)
                {
                    throw;
                }

                log(
                    "Локальный сертификат OPC UA клиента невалиден. " +
                    "Пересоздаю только собственный pki\\own.");

                if (Directory.Exists(ownDirectory))
                {
                    Directory.Delete(ownDirectory, true);
                }

                config = CreateConfiguration(options.PkiDirectory);
                application = new ApplicationInstance(config);
                application.ApplicationName = config.ApplicationName;
                application.ApplicationType = ApplicationType.Client;

                certificateOk = application
                    .CheckApplicationInstanceCertificatesAsync(
                        true,
                        (ushort?)120,
                        ct)
                    .GetAwaiter()
                    .GetResult();
            }

            if (!certificateOk)
            {
                throw new InvalidOperationException(
                    "Не удалось подготовить сертификат OPC UA клиента.");
            }

            if (config.CertificateValidator != null)
            {
                config.CertificateValidator.CertificateValidation +=
                    delegate(CertificateValidator sender, CertificateValidationEventArgs e)
                    {
                        e.Accept = true;
                    };
            }

            EndpointDescription selectedEndpoint = null;
            ISession session = null;
            Exception lastConnectionError = null;

            bool[] securityAttempts = GetSecurityAttempts(options.SecurityMode);

            foreach (bool useSecurity in securityAttempts)
            {
                ct.ThrowIfCancellationRequested();

                try
                {
                    log("Выбор endpoint. Security=" + useSecurity);

                    selectedEndpoint = CoreClientUtils.SelectEndpoint(
                        config,
                        endpointUrl,
                        useSecurity,
                        15000);

                    if (selectedEndpoint == null)
                    {
                        throw new InvalidOperationException(
                            "OPC UA discovery не вернул подходящий endpoint.");
                    }

                    EndpointConfiguration endpointConfiguration =
                        EndpointConfiguration.Create(config);

                    ConfiguredEndpoint configuredEndpoint =
                        new ConfiguredEndpoint(
                            null,
                            selectedEndpoint,
                            endpointConfiguration);

                    IUserIdentity identity = CreateIdentity(options);

                    session = DefaultSessionFactory.Instance
                        .CreateAsync(
                            config,
                            configuredEndpoint,
                            true,
                            false,
                            "DigitalWater.PLCResearch",
                            60000,
                            identity,
                            null,
                            ct)
                        .GetAwaiter()
                        .GetResult();

                    if (session == null || !session.Connected)
                    {
                        throw new InvalidOperationException(
                            "OPC UA session не перешла в Connected.");
                    }

                    break;
                }
                catch (Exception ex)
                {
                    lastConnectionError = ex;
                    log("Подключение не выполнено: " + ex.Message);

                    if (session != null)
                    {
                        try { session.Dispose(); } catch { }
                        session = null;
                    }
                }
            }

            if (session == null)
            {
                throw new InvalidOperationException(
                    "Не удалось подключиться к PLC по OPC UA. " +
                    (lastConnectionError == null
                        ? ""
                        : lastConnectionError.Message));
            }

            try
            {
                Report(progress, "Исследование адресного пространства",
                    "OPC UA session подключена.", null);

                log("Connected endpoint: " + selectedEndpoint.EndpointUrl);
                log("SecurityPolicy: " + selectedEndpoint.SecurityPolicyUri);
                log("SecurityMode: " + selectedEndpoint.SecurityMode);

                BrowseOutcome browse = BrowseVariables(
                    session,
                    progress,
                    ct,
                    log);

                List<ResearchItem> items = ReadMetadata(
                    session,
                    browse.Variables,
                    options.ReadCurrentValues,
                    browse.BrowsedNodeCount,
                    progress,
                    ct,
                    log);

                ResearchResult result = new ResearchResult();
                result.Contract =
                    "DIGITALWATER.OPCUA_PLC_RESEARCH_STANDALONE/1.1";
                result.Protocol = "OPC_UA";
                result.BasedOnLocalAppContract =
                    "DIGITALWATER.OPCUA_PLC_RESEARCH/1.0";
                result.Mode = "READ_ONLY_DIRECT_OPCUA";
                result.EndpointInput = options.Endpoint;
                result.EndpointUrl = endpointUrl;
                result.SelectedEndpointUrl = selectedEndpoint.EndpointUrl;
                result.SecurityMode = selectedEndpoint.SecurityMode.ToString();
                result.SecurityPolicyUri = selectedEndpoint.SecurityPolicyUri;
                result.Authentication =
                    options.Anonymous ? "Anonymous" : "UserName";
                result.StartedAtUtc = started;
                result.CompletedAtUtc = DateTimeOffset.UtcNow;
                result.BrowsedNodeCount = browse.BrowsedNodeCount;
                result.VariableCount = items.Count;
                result.Truncated = browse.Truncated;
                result.ReadCurrentValues = options.ReadCurrentValues;
                result.Items = items;
                result.Namespaces = GetNamespaces(session);
                result.Server = BuildServerInfo(selectedEndpoint);

                return result;
            }
            finally
            {
                try
                {
                    session.Close(5000);
                }
                catch
                {
                }

                try
                {
                    session.Dispose();
                }
                catch
                {
                }
            }
        }

        private static ApplicationConfiguration CreateConfiguration(
            string pkiDirectory)
        {
            Directory.CreateDirectory(pkiDirectory);

            ApplicationConfiguration config =
                new ApplicationConfiguration();

            config.ApplicationName = "DigitalWater PLC Research";
            config.ApplicationUri =
                "urn:" + Utils.GetHostName() + ":DigitalWater:PLCResearch";
            config.ProductUri = "urn:DigitalWater:PLCResearch";
            config.ApplicationType = ApplicationType.Client;

            SecurityConfiguration security =
                new SecurityConfiguration();

            security.ApplicationCertificate =
                new CertificateIdentifier
                {
                    StoreType = "Directory",
                    StorePath = Path.Combine(pkiDirectory, "own"),
                    SubjectName =
                        "CN=DigitalWater PLC Research, O=DigitalWater"
                };

            security.TrustedPeerCertificates =
                new CertificateTrustList
                {
                    StoreType = "Directory",
                    StorePath = Path.Combine(pkiDirectory, "trusted")
                };

            security.TrustedIssuerCertificates =
                new CertificateTrustList
                {
                    StoreType = "Directory",
                    StorePath = Path.Combine(pkiDirectory, "issuer")
                };

            security.RejectedCertificateStore =
                new CertificateStoreIdentifier
                {
                    StoreType = "Directory",
                    StorePath = Path.Combine(pkiDirectory, "rejected")
                };

            security.AutoAcceptUntrustedCertificates = true;
            security.RejectSHA1SignedCertificates = false;
            security.RejectUnknownRevocationStatus = false;
            security.MinimumCertificateKeySize = 1024;
            security.AddAppCertToTrustedStore = true;
            security.SendCertificateChain = true;

            config.SecurityConfiguration = security;

            config.TransportQuotas =
                new TransportQuotas
                {
                    OperationTimeout = 120000,
                    MaxStringLength = 1048576,
                    MaxByteStringLength = 1048576,
                    MaxArrayLength = 65535,
                    MaxMessageSize = 4194304,
                    MaxBufferSize = 65535,
                    ChannelLifetime = 300000,
                    SecurityTokenLifetime = 3600000
                };

            config.ClientConfiguration =
                new ClientConfiguration
                {
                    DefaultSessionTimeout = 60000,
                    MinSubscriptionLifetime = 10000
                };

            config.Validate(ApplicationType.Client)
                .GetAwaiter()
                .GetResult();

            return config;
        }

        private static IUserIdentity CreateIdentity(ScanOptions options)
        {
            if (options.Anonymous)
            {
                return new UserIdentity(
                    (UserIdentityToken)new AnonymousIdentityToken());
            }

            if (String.IsNullOrWhiteSpace(options.Username))
            {
                throw new InvalidOperationException(
                    "Для неанонимного подключения требуется пользователь.");
            }

            byte[] password =
                Encoding.UTF8.GetBytes(options.Password ?? String.Empty);

            return new UserIdentity(
                options.Username,
                password);
        }

        private static bool[] GetSecurityAttempts(int mode)
        {
            if (mode == 1)
            {
                return new bool[] { true };
            }

            if (mode == 2)
            {
                return new bool[] { false };
            }

            return new bool[] { true, false };
        }

        private static string NormalizeEndpoint(string raw)
        {
            string value = (raw ?? String.Empty).Trim();

            if (value.Length == 0)
            {
                throw new InvalidOperationException(
                    "Укажите IP или OPC UA endpoint PLC.");
            }

            string candidate = value.IndexOf("://", StringComparison.Ordinal) >= 0
                ? value
                : "opc.tcp://" + value;

            Uri uri;
            if (!Uri.TryCreate(candidate, UriKind.Absolute, out uri) ||
                !String.Equals(
                    uri.Scheme,
                    "opc.tcp",
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "Допустим IP, host:port или opc.tcp://...");
            }

            if (uri.Port <= 0 || uri.IsDefaultPort)
            {
                UriBuilder builder = new UriBuilder(uri);
                builder.Port = 4840;
                candidate = builder.Uri.ToString();
            }

            return candidate.TrimEnd('/');
        }

        private static BrowseOutcome BrowseVariables(
            ISession session,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            Browser browser = new Browser((ISessionClient)session);
            browser.BrowseDirection = BrowseDirection.Forward;
            browser.ReferenceTypeId = ReferenceTypeIds.HierarchicalReferences;
            browser.IncludeSubtypes = true;
            browser.NodeClassMask =
                (uint)(NodeClass.Object | NodeClass.Variable);
            browser.ResultMask = (uint)BrowseResultMask.All;
            browser.ContinueUntilDone = true;

            Queue<BrowseWorkItem> pending =
                new Queue<BrowseWorkItem>();

            HashSet<string> visited =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            List<VariableRef> variables =
                new List<VariableRef>();

            pending.Enqueue(
                new BrowseWorkItem(
                    ObjectIds.ObjectsFolder,
                    "Objects",
                    0));

            visited.Add(ObjectIds.ObjectsFolder.ToString());

            Report(
                progress,
                "Исследование адресного пространства",
                "Просмотрено узлов: 1 · найдено переменных: 0",
                null);

            while (pending.Count > 0 &&
                   visited.Count < MaxNodes)
            {
                ct.ThrowIfCancellationRequested();

                List<BrowseWorkItem> batch =
                    new List<BrowseWorkItem>();

                while (pending.Count > 0 &&
                       batch.Count < BrowseBatchSize)
                {
                    BrowseWorkItem item = pending.Dequeue();
                    if (item.Depth < MaxDepth)
                    {
                        batch.Add(item);
                    }
                }

                if (batch.Count == 0)
                {
                    continue;
                }

                List<NodeId> nodeIds =
                    batch.Select(x => x.NodeId).ToList();

                ResultSet<ReferenceDescriptionCollection> browseResult;

                try
                {
                    browseResult = browser
                        .BrowseAsync(nodeIds, ct)
                        .GetAwaiter()
                        .GetResult();
                }
                catch (Exception ex)
                {
                    log("Browse batch skipped: " + ex.Message);
                    continue;
                }

                for (int batchIndex = 0;
                     batchIndex < batch.Count;
                     batchIndex++)
                {
                    if (StatusCode.IsBad(
                        browseResult.Errors[batchIndex].StatusCode))
                    {
                        log(
                            "Browse skipped " +
                            batch[batchIndex].NodeId +
                            ": " +
                            browseResult.Errors[batchIndex].StatusCode);

                        continue;
                    }

                    ReferenceDescriptionCollection references =
                        browseResult.Results[batchIndex];

                    if (references == null)
                    {
                        continue;
                    }

                    foreach (ReferenceDescription reference in references)
                    {
                        if (visited.Count >= MaxNodes)
                        {
                            break;
                        }

                        NodeId childId =
                            ExpandedNodeId.ToNodeId(
                                reference.NodeId,
                                session.NamespaceUris);

                        if (childId == null ||
                            childId == ObjectIds.Server)
                        {
                            continue;
                        }

                        string key = childId.ToString();

                        if (!visited.Add(key))
                        {
                            continue;
                        }

                        string name =
                            reference.BrowseName != null &&
                            !String.IsNullOrWhiteSpace(
                                reference.BrowseName.Name)
                                ? reference.BrowseName.Name
                                : (
                                    reference.DisplayName != null &&
                                    !String.IsNullOrWhiteSpace(
                                        reference.DisplayName.Text)
                                        ? reference.DisplayName.Text
                                        : key);

                        string path =
                            batch[batchIndex].Path +
                            "/" +
                            name;

                        if (reference.NodeClass ==
                            NodeClass.Variable)
                        {
                            VariableRef variable =
                                new VariableRef();

                            variable.NodeId = childId;
                            variable.BrowsePath = path;
                            variable.Reference = reference;
                            variables.Add(variable);
                        }

                        if (reference.NodeClass ==
                                NodeClass.Object ||
                            reference.NodeClass ==
                                NodeClass.Variable)
                        {
                            pending.Enqueue(
                                new BrowseWorkItem(
                                    childId,
                                    path,
                                    batch[batchIndex].Depth + 1));
                        }
                    }
                }

                Report(
                    progress,
                    "Исследование адресного пространства",
                    "Просмотрено узлов: " +
                    visited.Count +
                    " · найдено переменных: " +
                    variables.Count,
                    null);
            }

            BrowseOutcome outcome = new BrowseOutcome();
            outcome.BrowsedNodeCount = visited.Count;
            outcome.Truncated =
                visited.Count >= MaxNodes &&
                pending.Count > 0;
            outcome.Variables = variables;

            log(
                "Browse completed. Nodes=" +
                outcome.BrowsedNodeCount +
                ", Variables=" +
                variables.Count +
                ", Truncated=" +
                outcome.Truncated);

            return outcome;
        }

        private static List<ResearchItem> ReadMetadata(
            ISession session,
            List<VariableRef> variables,
            bool readCurrentValues,
            int browsedNodeCount,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            List<ResearchItem> results =
                new List<ResearchItem>();

            int attributesPerNode =
                readCurrentValues ? 9 : 8;

            int processed = 0;

            for (int offset = 0;
                 offset < variables.Count;
                 offset += MetadataBatchSize)
            {
                ct.ThrowIfCancellationRequested();

                int count =
                    Math.Min(
                        MetadataBatchSize,
                        variables.Count - offset);

                List<VariableRef> chunk =
                    variables.GetRange(offset, count);

                ReadValueIdCollection nodesToRead =
                    new ReadValueIdCollection();

                foreach (VariableRef variable in chunk)
                {
                    AddRead(nodesToRead, variable.NodeId, Attributes.Description);
                    AddRead(nodesToRead, variable.NodeId, Attributes.DataType);
                    AddRead(nodesToRead, variable.NodeId, Attributes.ValueRank);
                    AddRead(nodesToRead, variable.NodeId, Attributes.ArrayDimensions);
                    AddRead(nodesToRead, variable.NodeId, Attributes.AccessLevel);
                    AddRead(nodesToRead, variable.NodeId, Attributes.UserAccessLevel);
                    AddRead(nodesToRead, variable.NodeId, Attributes.Historizing);
                    AddRead(nodesToRead, variable.NodeId, Attributes.MinimumSamplingInterval);

                    if (readCurrentValues)
                    {
                        AddRead(nodesToRead, variable.NodeId, Attributes.Value);
                    }
                }

                ReadResponse response;

                try
                {
                    response = session
                        .ReadAsync(
                            null,
                            0,
                            TimestampsToReturn.Both,
                            nodesToRead,
                            ct)
                        .GetAwaiter()
                        .GetResult();
                }
                catch (Exception ex)
                {
                    log("Metadata batch failed: " + ex.Message);

                    foreach (VariableRef variable in chunk)
                    {
                        results.Add(
                            BuildFailedItem(
                                session,
                                variable,
                                ex.Message));
                    }

                    processed += chunk.Count;
                    ReportMetadataProgress(
                        progress,
                        browsedNodeCount,
                        variables.Count,
                        processed);

                    continue;
                }

                for (int i = 0; i < chunk.Count; i++)
                {
                    VariableRef variable = chunk[i];
                    int baseIndex =
                        i * attributesPerNode;

                    DataValue descriptionValue =
                        At(response, baseIndex + 0);
                    DataValue dataTypeValue =
                        At(response, baseIndex + 1);
                    DataValue valueRankValue =
                        At(response, baseIndex + 2);
                    DataValue arrayDimensionsValue =
                        At(response, baseIndex + 3);
                    DataValue accessLevelValue =
                        At(response, baseIndex + 4);
                    DataValue userAccessLevelValue =
                        At(response, baseIndex + 5);
                    DataValue historizingValue =
                        At(response, baseIndex + 6);
                    DataValue minimumSamplingValue =
                        At(response, baseIndex + 7);

                    DataValue currentValue =
                        readCurrentValues
                            ? At(response, baseIndex + 8)
                            : null;

                    ResearchItem item =
                        BuildItem(
                            session,
                            variable,
                            descriptionValue,
                            dataTypeValue,
                            valueRankValue,
                            arrayDimensionsValue,
                            accessLevelValue,
                            userAccessLevelValue,
                            historizingValue,
                            minimumSamplingValue,
                            currentValue);

                    results.Add(item);
                }

                processed += chunk.Count;

                ReportMetadataProgress(
                    progress,
                    browsedNodeCount,
                    variables.Count,
                    processed);
            }

            return results;
        }

        private static void ReportMetadataProgress(
            IProgress<ScanProgress> progress,
            int browsedNodeCount,
            int total,
            int processed)
        {
            int percent = total <= 0
                ? 100
                : (int)Math.Min(
                    100,
                    Math.Round(
                        processed * 100.0 / total));

            Report(
                progress,
                "Чтение метаданных и значений",
                "Обработано: " +
                processed +
                " из " +
                total +
                " · просмотрено узлов: " +
                browsedNodeCount,
                percent);
        }

        private static void AddRead(
            ReadValueIdCollection collection,
            NodeId nodeId,
            uint attributeId)
        {
            ReadValueId value =
                new ReadValueId();

            value.NodeId = nodeId;
            value.AttributeId = attributeId;

            collection.Add(value);
        }

        private static DataValue At(
            ReadResponse response,
            int index)
        {
            if (response == null ||
                response.Results == null ||
                index < 0 ||
                index >= response.Results.Count)
            {
                return null;
            }

            return response.Results[index];
        }

        private static ResearchItem BuildItem(
            ISession session,
            VariableRef variable,
            DataValue descriptionValue,
            DataValue dataTypeValue,
            DataValue valueRankValue,
            DataValue arrayDimensionsValue,
            DataValue accessLevelValue,
            DataValue userAccessLevelValue,
            DataValue historizingValue,
            DataValue minimumSamplingValue,
            DataValue currentValue)
        {
            ResearchItem item =
                new ResearchItem();

            item.NodeId = variable.NodeId.ToString();
            item.NamespaceIndex =
                variable.NodeId.NamespaceIndex;
            item.NamespaceUri =
                session.NamespaceUris.GetString(
                    variable.NodeId.NamespaceIndex);
            item.BrowsePath =
                variable.BrowsePath;
            item.BrowseName =
                variable.Reference.BrowseName == null
                    ? String.Empty
                    : variable.Reference.BrowseName.Name;
            item.DisplayName =
                variable.Reference.DisplayName == null
                    ? String.Empty
                    : variable.Reference.DisplayName.Text;
            item.Description =
                ReadLocalizedText(descriptionValue);
            item.NodeClass =
                variable.Reference.NodeClass.ToString();
            item.TypeDefinitionId =
                variable.Reference.TypeDefinition == null
                    ? null
                    : variable.Reference.TypeDefinition.ToString();

            NodeId dataTypeNodeId =
                dataTypeValue == null
                    ? null
                    : dataTypeValue.Value as NodeId;

            item.DataTypeNodeId =
                dataTypeNodeId == null
                    ? null
                    : dataTypeNodeId.ToString();

            if (dataTypeNodeId != null &&
                IsGood(dataTypeValue))
            {
                try
                {
                    BuiltInType builtInType =
                        TypeInfo.GetBuiltInType(
                            dataTypeNodeId,
                            session.TypeTree);

                    item.DataTypeName =
                        builtInType == BuiltInType.Null
                            ? null
                            : builtInType.ToString();
                }
                catch
                {
                    item.DataTypeName = null;
                }
            }

            if (IsGood(valueRankValue) &&
                valueRankValue.Value != null)
            {
                item.ValueRank =
                    Convert.ToInt32(
                        valueRankValue.Value,
                        CultureInfo.InvariantCulture);
            }

            item.ArrayDimensions =
                FormatArrayDimensions(
                    arrayDimensionsValue);

            if (IsGood(accessLevelValue) &&
                accessLevelValue.Value != null)
            {
                item.AccessLevel =
                    Convert.ToByte(
                        accessLevelValue.Value,
                        CultureInfo.InvariantCulture);
            }

            if (IsGood(userAccessLevelValue) &&
                userAccessLevelValue.Value != null)
            {
                item.UserAccessLevel =
                    Convert.ToByte(
                        userAccessLevelValue.Value,
                        CultureInfo.InvariantCulture);
            }

            if (IsGood(historizingValue) &&
                historizingValue.Value != null)
            {
                item.Historizing =
                    Convert.ToBoolean(
                        historizingValue.Value,
                        CultureInfo.InvariantCulture);
            }

            if (IsGood(minimumSamplingValue) &&
                minimumSamplingValue.Value != null)
            {
                item.MinimumSamplingInterval =
                    Convert.ToDouble(
                        minimumSamplingValue.Value,
                        CultureInfo.InvariantCulture);
            }

            bool metadataOk =
                dataTypeValue != null &&
                IsGood(dataTypeValue);

            item.Status =
                metadataOk ? "OK" : "READ_FAILED";

            if (!metadataOk)
            {
                item.Error =
                    dataTypeValue == null
                        ? "DataType attribute was not returned."
                        : dataTypeValue.StatusCode.ToString();
            }

            if (currentValue != null)
            {
                item.ValueStatus =
                    currentValue.StatusCode.ToString();
                item.ValueType =
                    currentValue.Value == null
                        ? null
                        : currentValue.Value.GetType().FullName;
                item.Value =
                    NormalizeValue(currentValue.Value);
                item.SourceTimestamp =
                    NormalizeTimestamp(
                        currentValue.SourceTimestamp);
                item.ServerTimestamp =
                    NormalizeTimestamp(
                        currentValue.ServerTimestamp);
            }

            return item;
        }

        private static ResearchItem BuildFailedItem(
            ISession session,
            VariableRef variable,
            string error)
        {
            ResearchItem item =
                new ResearchItem();

            item.NodeId = variable.NodeId.ToString();
            item.NamespaceIndex =
                variable.NodeId.NamespaceIndex;
            item.NamespaceUri =
                session.NamespaceUris.GetString(
                    variable.NodeId.NamespaceIndex);
            item.BrowsePath =
                variable.BrowsePath;
            item.BrowseName =
                variable.Reference.BrowseName == null
                    ? String.Empty
                    : variable.Reference.BrowseName.Name;
            item.DisplayName =
                variable.Reference.DisplayName == null
                    ? String.Empty
                    : variable.Reference.DisplayName.Text;
            item.NodeClass =
                variable.Reference.NodeClass.ToString();
            item.TypeDefinitionId =
                variable.Reference.TypeDefinition == null
                    ? null
                    : variable.Reference.TypeDefinition.ToString();
            item.Status = "READ_FAILED";
            item.Error = error;

            return item;
        }

        private static bool IsGood(DataValue value)
        {
            return value != null &&
                ServiceResult.IsGood(value.StatusCode);
        }

        private static string ReadLocalizedText(
            DataValue value)
        {
            if (!IsGood(value) ||
                value.Value == null)
            {
                return null;
            }

            LocalizedText localized =
                value.Value as LocalizedText;

            if (localized != null)
            {
                return localized.Text;
            }

            return Convert.ToString(
                value.Value,
                CultureInfo.InvariantCulture);
        }

        private static string FormatArrayDimensions(
            DataValue value)
        {
            if (!IsGood(value) ||
                value.Value == null)
            {
                return null;
            }

            IEnumerable enumerable =
                value.Value as IEnumerable;

            if (enumerable == null ||
                value.Value is string)
            {
                return Convert.ToString(
                    value.Value,
                    CultureInfo.InvariantCulture);
            }

            List<string> parts =
                new List<string>();

            foreach (object item in enumerable)
            {
                parts.Add(
                    Convert.ToString(
                        item,
                        CultureInfo.InvariantCulture));
            }

            return String.Join("x", parts.ToArray());
        }

        private static object NormalizeValue(object value)
        {
            if (value == null)
            {
                return null;
            }

            Type type = value.GetType();

            if (type.IsPrimitive ||
                value is decimal ||
                value is string ||
                value is DateTime ||
                value is DateTimeOffset ||
                value is Guid)
            {
                return value;
            }

            byte[] bytes = value as byte[];
            if (bytes != null)
            {
                return Convert.ToBase64String(bytes);
            }

            Array array = value as Array;
            if (array != null)
            {
                List<object> values =
                    new List<object>();

                int count =
                    Math.Min(array.Length, 2048);

                for (int i = 0; i < count; i++)
                {
                    values.Add(
                        NormalizeValue(
                            array.GetValue(i)));
                }

                if (array.Length > count)
                {
                    values.Add(
                        "... truncated " +
                        (array.Length - count) +
                        " items");
                }

                return values;
            }

            LocalizedText localized =
                value as LocalizedText;
            if (localized != null)
            {
                return localized.Text;
            }

            QualifiedName qn =
                value as QualifiedName;
            if (qn != null)
            {
                return qn.ToString();
            }

            NodeId nodeId =
                value as NodeId;
            if (nodeId != null)
            {
                return nodeId.ToString();
            }

            return value.ToString();
        }

        private static DateTimeOffset? NormalizeTimestamp(
            DateTime timestamp)
        {
            if (timestamp == DateTime.MinValue ||
                timestamp == DateTime.MaxValue)
            {
                return null;
            }

            DateTime utc =
                timestamp.Kind == DateTimeKind.Utc
                    ? timestamp
                    : timestamp.ToUniversalTime();

            return new DateTimeOffset(utc);
        }

        private static List<NamespaceInfo> GetNamespaces(
            ISession session)
        {
            List<NamespaceInfo> result =
                new List<NamespaceInfo>();

            for (int i = 0;
                 i < session.NamespaceUris.Count;
                 i++)
            {
                NamespaceInfo item =
                    new NamespaceInfo();

                item.Index = i;
                item.Uri =
                    session.NamespaceUris.GetString((uint)i);

                result.Add(item);
            }

            return result;
        }

        private static ServerInfo BuildServerInfo(
            EndpointDescription endpoint)
        {
            ServerInfo info = new ServerInfo();

            if (endpoint != null &&
                endpoint.Server != null)
            {
                info.ApplicationName =
                    endpoint.Server.ApplicationName == null
                        ? null
                        : endpoint.Server.ApplicationName.Text;
                info.ApplicationUri =
                    endpoint.Server.ApplicationUri;
                info.ProductUri =
                    endpoint.Server.ProductUri;
                info.ApplicationType =
                    endpoint.Server.ApplicationType.ToString();
            }

            return info;
        }

        private static void Report(
            IProgress<ScanProgress> progress,
            string stage,
            string details,
            int? percent)
        {
            if (progress == null)
            {
                return;
            }

            ScanProgress p = new ScanProgress();
            p.Stage = stage;
            p.Details = details;
            p.Percent = percent;
            progress.Report(p);
        }

        private sealed class BrowseWorkItem
        {
            public BrowseWorkItem(
                NodeId nodeId,
                string path,
                int depth)
            {
                NodeId = nodeId;
                Path = path;
                Depth = depth;
            }

            public NodeId NodeId;
            public string Path;
            public int Depth;
        }

        private sealed class VariableRef
        {
            public NodeId NodeId;
            public string BrowsePath;
            public ReferenceDescription Reference;
        }

        private sealed class BrowseOutcome
        {
            public int BrowsedNodeCount;
            public bool Truncated;
            public List<VariableRef> Variables;
        }
    }


    internal static class ComSecurity
    {
        private const uint RPC_C_AUTHN_LEVEL_PKT_INTEGRITY = 5;
        private const uint RPC_C_IMP_LEVEL_IMPERSONATE = 3;
        private const uint RPC_C_AUTHN_GSS_NEGOTIATE = 9;
        private const uint RPC_C_AUTHZ_NONE = 0;
        private const uint EOAC_NONE = 0;
        private const int RPC_E_TOO_LATE = unchecked((int)0x80010119);

        [DllImport("ole32.dll")]
        private static extern int CoInitializeSecurity(
            IntPtr pSecDesc,
            int cAuthSvc,
            IntPtr asAuthSvc,
            IntPtr pReserved1,
            uint dwAuthnLevel,
            uint dwImpLevel,
            IntPtr pAuthList,
            uint dwCapabilities,
            IntPtr pReserved3);

        [DllImport("ole32.dll", CharSet = CharSet.Unicode)]
        private static extern int CoSetProxyBlanket(
            IntPtr pProxy,
            uint dwAuthnSvc,
            uint dwAuthzSvc,
            string pServerPrincName,
            uint dwAuthnLevel,
            uint dwImpLevel,
            IntPtr pAuthInfo,
            uint dwCapabilities);

        public static void InitializeProcessSecurity()
        {
            if (!OperatingSystem.IsWindows())
            {
                return;
            }

            try
            {
                int hr = CoInitializeSecurity(
                    IntPtr.Zero,
                    -1,
                    IntPtr.Zero,
                    IntPtr.Zero,
                    RPC_C_AUTHN_LEVEL_PKT_INTEGRITY,
                    RPC_C_IMP_LEVEL_IMPERSONATE,
                    IntPtr.Zero,
                    EOAC_NONE,
                    IntPtr.Zero);

                if (hr < 0 && hr != RPC_E_TOO_LATE)
                {
                    Marshal.ThrowExceptionForHR(hr);
                }
            }
            catch
            {
                // Windows can initialize COM security earlier.
                // Individual proxies are additionally hardened below.
            }
        }

        public static void ApplyPacketIntegrity(object comObject)
        {
            if (comObject == null || !Marshal.IsComObject(comObject))
            {
                return;
            }

            IntPtr unknown = IntPtr.Zero;

            try
            {
                unknown = Marshal.GetIUnknownForObject(comObject);

                int hr = CoSetProxyBlanket(
                    unknown,
                    RPC_C_AUTHN_GSS_NEGOTIATE,
                    RPC_C_AUTHZ_NONE,
                    null,
                    RPC_C_AUTHN_LEVEL_PKT_INTEGRITY,
                    RPC_C_IMP_LEVEL_IMPERSONATE,
                    IntPtr.Zero,
                    EOAC_NONE);

                if (hr < 0)
                {
                    // Do not block local/legacy servers which negotiate differently.
                    // The COM call itself will return the useful DCOM error if access fails.
                }
            }
            catch
            {
            }
            finally
            {
                if (unknown != IntPtr.Zero)
                {
                    Marshal.Release(unknown);
                }
            }
        }
    }

    internal sealed class DaServerInfo
    {
        public Guid Clsid { get; set; }
        public string ProgId { get; set; }
        public string UserType { get; set; }
        public string VersionIndependentProgId { get; set; }
        public List<string> Versions { get; set; } = new List<string>();

        public override string ToString()
        {
            string id = !String.IsNullOrWhiteSpace(ProgId)
                ? ProgId
                : Clsid.ToString("B");

            string versionText = Versions.Count == 0
                ? ""
                : " [" + String.Join("/", Versions.ToArray()) + "]";

            string name = String.IsNullOrWhiteSpace(UserType)
                ? ""
                : " — " + UserType;

            return id + name + versionText;
        }
    }

    internal sealed class DaScanOptions
    {
        public string Host { get; set; }
        public string ServerToken { get; set; }
        public Guid? Clsid { get; set; }
        public List<string> KnownVersions { get; set; }
        public string ServerUserType { get; set; }
        public bool ReadCurrentValues { get; set; }
    }

    internal sealed class OpcDaScanner
    {
        private static readonly Guid OpcEnumClsid =
            new Guid("13486D51-4821-11D2-A494-3CB306C10000");

        private static readonly Guid CatDa10 =
            new Guid("63D5F430-CFE4-11D1-B2C8-0060083BA1FB");

        private static readonly Guid CatDa20 =
            new Guid("63D5F432-CFE4-11D1-B2C8-0060083BA1FB");

        private static readonly Guid CatDa30 =
            new Guid("CC603642-66D7-48F1-B69A-B625E73652D7");

        private const int MaxItems = 50000;
        private const int MaxDepth = 64;

        [DllImport("oleaut32.dll")]
        private static extern int VariantClear(IntPtr pvarg);

        public static List<DaServerInfo> DiscoverServers(
            string host,
            CancellationToken ct,
            Action<string> log)
        {
            string normalizedHost = NormalizeHost(host);
            object opcEnumObject = null;
            IOPCServerList2 serverList = null;

            try
            {
                Type opcEnumType = IsLocalHost(normalizedHost)
                    ? Type.GetTypeFromCLSID(OpcEnumClsid, true)
                    : Type.GetTypeFromCLSID(OpcEnumClsid, normalizedHost, true);

                opcEnumObject = Activator.CreateInstance(opcEnumType);
                ComSecurity.ApplyPacketIntegrity(opcEnumObject);
                serverList = (IOPCServerList2)opcEnumObject;

                Dictionary<Guid, DaServerInfo> servers =
                    new Dictionary<Guid, DaServerInfo>();

                DiscoverCategory(
                    serverList,
                    CatDa10,
                    "DA1",
                    servers,
                    ct,
                    log);

                DiscoverCategory(
                    serverList,
                    CatDa20,
                    "DA2",
                    servers,
                    ct,
                    log);

                DiscoverCategory(
                    serverList,
                    CatDa30,
                    "DA3",
                    servers,
                    ct,
                    log);

                List<DaServerInfo> result = servers.Values.ToList();
                result.Sort(
                    delegate(DaServerInfo a, DaServerInfo b)
                    {
                        return String.Compare(
                            a.ProgId,
                            b.ProgId,
                            StringComparison.OrdinalIgnoreCase);
                    });

                return result;
            }
            finally
            {
                ReleaseCom(serverList);
                if (!Object.ReferenceEquals(serverList, opcEnumObject))
                {
                    ReleaseCom(opcEnumObject);
                }
            }
        }

        private static void DiscoverCategory(
            IOPCServerList2 serverList,
            Guid category,
            string version,
            Dictionary<Guid, DaServerInfo> servers,
            CancellationToken ct,
            Action<string> log)
        {
            IOPCEnumGUID enumerator = null;

            try
            {
                serverList.EnumClassesOfCategories(
                    1,
                    new Guid[] { category },
                    0,
                    null,
                    out enumerator);

                ComSecurity.ApplyPacketIntegrity(enumerator);

                foreach (Guid clsid in ReadGuids(enumerator, ct))
                {
                    ct.ThrowIfCancellationRequested();

                    DaServerInfo info;
                    if (!servers.TryGetValue(clsid, out info))
                    {
                        info = new DaServerInfo();
                        info.Clsid = clsid;

                        try
                        {
                            string progId;
                            string userType;
                            string versionIndependentProgId;
                            Guid localClsid = clsid;

                            serverList.GetClassDetails(
                                ref localClsid,
                                out progId,
                                out userType,
                                out versionIndependentProgId);

                            info.ProgId = progId;
                            info.UserType = userType;
                            info.VersionIndependentProgId =
                                versionIndependentProgId;
                        }
                        catch (Exception ex)
                        {
                            log(
                                "OPCEnum GetClassDetails " +
                                clsid +
                                ": " +
                                ex.Message);
                        }

                        servers.Add(clsid, info);
                    }

                    if (!info.Versions.Contains(version))
                    {
                        info.Versions.Add(version);
                    }
                }
            }
            finally
            {
                ReleaseCom(enumerator);
            }
        }

        public ResearchResult Scan(
            DaScanOptions options,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            if (!OperatingSystem.IsWindows())
            {
                throw new PlatformNotSupportedException(
                    "OPC DA COM/DCOM поддерживается только в Windows.");
            }

            DateTimeOffset started = DateTimeOffset.UtcNow;
            string host = NormalizeHost(options.Host);

            Report(
                progress,
                "Подключение к OPC DA Server",
                host + " / " + options.ServerToken,
                null);

            object serverObject = null;
            IOPCBrowseServerAddressSpace browser = null;
            IOPCItemProperties properties = null;

            Guid? usedClsid = options.Clsid;
            string usedProgId = options.ServerToken;

            try
            {
                Type serverType;

                if (options.Clsid.HasValue)
                {
                    serverType = IsLocalHost(host)
                        ? Type.GetTypeFromCLSID(
                            options.Clsid.Value,
                            true)
                        : Type.GetTypeFromCLSID(
                            options.Clsid.Value,
                            host,
                            true);
                }
                else
                {
                    Guid parsed;
                    if (Guid.TryParse(
                        options.ServerToken.Trim().Trim('{', '}'),
                        out parsed))
                    {
                        usedClsid = parsed;

                        serverType = IsLocalHost(host)
                            ? Type.GetTypeFromCLSID(parsed, true)
                            : Type.GetTypeFromCLSID(
                                parsed,
                                host,
                                true);
                    }
                    else
                    {
                        serverType = IsLocalHost(host)
                            ? Type.GetTypeFromProgID(
                                options.ServerToken,
                                true)
                            : Type.GetTypeFromProgID(
                                options.ServerToken,
                                host,
                                true);
                    }
                }

                if (serverType == null)
                {
                    throw new InvalidOperationException(
                        "Windows не смогла разрешить указанный OPC DA ProgID/CLSID.");
                }

                serverObject = Activator.CreateInstance(serverType);
                ComSecurity.ApplyPacketIntegrity(serverObject);

                log(
                    "OPC DA COM object activated: " +
                    serverType.FullName);

                try
                {
                    browser =
                        (IOPCBrowseServerAddressSpace)serverObject;
                    ComSecurity.ApplyPacketIntegrity(browser);
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        "OPC DA Server не предоставляет интерфейс " +
                        "IOPCBrowseServerAddressSpace (DA 1.0/2.05a compatibility). " +
                        "Если это сервер только DA3 без совместимого browse-интерфейса, " +
                        "его DA3 browse нужно добавить отдельным адаптером. " +
                        "Исходная ошибка: " +
                        ex.Message,
                        ex);
                }

                try
                {
                    properties = (IOPCItemProperties)serverObject;
                    ComSecurity.ApplyPacketIntegrity(properties);
                }
                catch
                {
                    properties = null;
                    log(
                        "IOPCItemProperties недоступен. " +
                        "ItemID будут исследованы, но тип/value/quality могут отсутствовать.");
                }

                OPCNAMESPACETYPE organization;
                browser.QueryOrganization(out organization);

                log("OPC DA namespace: " + organization);

                BrowseResult browseResult = new BrowseResult();

                if (organization == OPCNAMESPACETYPE.OPC_NS_FLAT)
                {
                    BrowseFlat(
                        browser,
                        browseResult,
                        progress,
                        ct,
                        log);
                }
                else
                {
                    BrowseHierarchical(
                        browser,
                        "",
                        0,
                        browseResult,
                        progress,
                        ct,
                        log);
                }

                Report(
                    progress,
                    "Чтение свойств OPC DA Items",
                    "Найдено Item: " + browseResult.Items.Count,
                    browseResult.Items.Count == 0 ? 100 : 0);

                int processed = 0;

                foreach (ResearchItem item in browseResult.Items)
                {
                    ct.ThrowIfCancellationRequested();

                    if (properties != null)
                    {
                        ReadStandardProperties(
                            properties,
                            item,
                            options.ReadCurrentValues);
                    }

                    processed++;

                    if (processed % 10 == 0 ||
                        processed == browseResult.Items.Count)
                    {
                        int percent =
                            browseResult.Items.Count == 0
                                ? 100
                                : (int)Math.Min(
                                    100,
                                    Math.Round(
                                        processed *
                                        100.0 /
                                        browseResult.Items.Count));

                        Report(
                            progress,
                            "Чтение свойств OPC DA Items",
                            "Обработано: " +
                            processed +
                            " из " +
                            browseResult.Items.Count,
                            percent);
                    }
                }

                ResearchResult result = new ResearchResult();
                result.Contract =
                    "DIGITALWATER.OPCDA_PLC_RESEARCH_STANDALONE/1.0";
                result.Protocol = "OPC_DA";
                result.Mode = "READ_ONLY_DIRECT_OPC_DA_COM_DCOM";
                result.Host = host;
                result.ProgId = usedProgId;
                result.Clsid =
                    usedClsid.HasValue
                        ? usedClsid.Value.ToString("B")
                        : null;
                result.ServerUserType = options.ServerUserType;
                result.OpcDaVersions =
                    options.KnownVersions ?? new List<string>();
                result.Authentication =
                    "CurrentWindowsIdentity";
                result.StartedAtUtc = started;
                result.CompletedAtUtc = DateTimeOffset.UtcNow;
                result.BrowsedNodeCount = browseResult.BrowsedCount;
                result.VariableCount = browseResult.Items.Count;
                result.Truncated = browseResult.Truncated;
                result.ReadCurrentValues =
                    options.ReadCurrentValues;
                result.Items = browseResult.Items;
                result.Namespaces =
                    new List<NamespaceInfo>();
                result.Server = new ServerInfo();
                result.Server.ApplicationName =
                    options.ServerUserType;
                result.Server.ApplicationType = "OPC DA";
                result.Server.ProgId = usedProgId;
                result.Server.Clsid = result.Clsid;
                result.Server.Host = host;

                return result;
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException(
                    BuildComDiagnostic(ex, host),
                    ex);
            }
            finally
            {
                ReleaseCom(properties);
                ReleaseCom(browser);

                if (!Object.ReferenceEquals(
                    properties,
                    serverObject) &&
                    !Object.ReferenceEquals(
                        browser,
                        serverObject))
                {
                    ReleaseCom(serverObject);
                }
            }
        }

        private static void BrowseFlat(
            IOPCBrowseServerAddressSpace browser,
            BrowseResult result,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            List<string> names =
                BrowseStrings(
                    browser,
                    OPCBROWSETYPE.OPC_FLAT,
                    ct);

            foreach (string name in names)
            {
                ct.ThrowIfCancellationRequested();

                if (result.Items.Count >= MaxItems)
                {
                    result.Truncated = true;
                    break;
                }

                string itemId = ResolveItemId(browser, name);
                AddDaItem(
                    result,
                    itemId,
                    itemId,
                    name);

                ReportBrowseProgress(
                    result,
                    progress);
            }
        }

        private static void BrowseHierarchical(
            IOPCBrowseServerAddressSpace browser,
            string path,
            int depth,
            BrowseResult result,
            IProgress<ScanProgress> progress,
            CancellationToken ct,
            Action<string> log)
        {
            ct.ThrowIfCancellationRequested();

            if (depth > MaxDepth)
            {
                result.Truncated = true;
                return;
            }

            result.BrowsedCount++;

            List<string> leaves =
                BrowseStrings(
                    browser,
                    OPCBROWSETYPE.OPC_LEAF,
                    ct);

            foreach (string leaf in leaves)
            {
                ct.ThrowIfCancellationRequested();

                if (result.Items.Count >= MaxItems)
                {
                    result.Truncated = true;
                    return;
                }

                string itemId = ResolveItemId(browser, leaf);
                string browsePath =
                    String.IsNullOrEmpty(path)
                        ? leaf
                        : path + "/" + leaf;

                AddDaItem(
                    result,
                    itemId,
                    browsePath,
                    leaf);
            }

            ReportBrowseProgress(result, progress);

            List<string> branches =
                BrowseStrings(
                    browser,
                    OPCBROWSETYPE.OPC_BRANCH,
                    ct);

            foreach (string branch in branches)
            {
                ct.ThrowIfCancellationRequested();

                if (result.Items.Count >= MaxItems)
                {
                    result.Truncated = true;
                    return;
                }

                string childPath =
                    String.IsNullOrEmpty(path)
                        ? branch
                        : path + "/" + branch;

                if (!result.VisitedBranches.Add(childPath))
                {
                    continue;
                }

                bool movedDown = false;

                try
                {
                    browser.ChangeBrowsePosition(
                        OPCBROWSEDIRECTION.OPC_BROWSE_DOWN,
                        branch);

                    movedDown = true;

                    BrowseHierarchical(
                        browser,
                        childPath,
                        depth + 1,
                        result,
                        progress,
                        ct,
                        log);
                }
                catch (COMException ex)
                {
                    log(
                        "Browse branch skipped: " +
                        childPath +
                        " / " +
                        ex.Message);
                }
                finally
                {
                    if (movedDown)
                    {
                        try
                        {
                            browser.ChangeBrowsePosition(
                                OPCBROWSEDIRECTION.OPC_BROWSE_UP,
                                "");
                        }
                        catch (Exception ex)
                        {
                            throw new InvalidOperationException(
                                "OPC DA browse position could not return to parent branch: " +
                                childPath +
                                ". " +
                                ex.Message,
                                ex);
                        }
                    }
                }
            }
        }

        private static void AddDaItem(
            BrowseResult result,
            string itemId,
            string browsePath,
            string browseName)
        {
            if (String.IsNullOrWhiteSpace(itemId))
            {
                return;
            }

            if (!result.ItemIds.Add(itemId))
            {
                return;
            }

            ResearchItem item = new ResearchItem();
            item.Protocol = "OPC_DA";
            item.ItemId = itemId;
            item.NodeId = null;
            item.BrowsePath = browsePath;
            item.BrowseName = browseName;
            item.DisplayName = browseName;
            item.NodeClass = "Item";
            item.Status = "BROWSED";

            result.Items.Add(item);
        }

        private static string ResolveItemId(
            IOPCBrowseServerAddressSpace browser,
            string browseName)
        {
            try
            {
                string itemId;
                browser.GetItemID(
                    browseName,
                    out itemId);

                if (!String.IsNullOrWhiteSpace(itemId))
                {
                    return itemId;
                }
            }
            catch
            {
            }

            return browseName;
        }

        private static List<string> BrowseStrings(
            IOPCBrowseServerAddressSpace browser,
            OPCBROWSETYPE type,
            CancellationToken ct)
        {
            IEnumString enumerator = null;

            try
            {
                browser.BrowseOPCItemIDs(
                    type,
                    "",
                    0,
                    0,
                    out enumerator);

                ComSecurity.ApplyPacketIntegrity(enumerator);

                return ReadStrings(enumerator, ct);
            }
            finally
            {
                ReleaseCom(enumerator);
            }
        }

        private static void ReadStandardProperties(
            IOPCItemProperties properties,
            ResearchItem item,
            bool readCurrentValues)
        {
            List<string> errors = new List<string>();

            object dataType;
            int dataTypeHr;

            if (TryReadProperty(
                properties,
                item.ItemId,
                1,
                out dataType,
                out dataTypeHr))
            {
                int vt = Convert.ToInt32(
                    dataType,
                    CultureInfo.InvariantCulture);

                item.DataTypeName = VarTypeName(vt);
                item.DataTypeNodeId = "VARTYPE:" + vt;
            }
            else if (dataTypeHr < 0)
            {
                errors.Add(
                    "DataType=" +
                    HResultText(dataTypeHr));
            }

            object access;
            int accessHr;

            if (TryReadProperty(
                properties,
                item.ItemId,
                5,
                out access,
                out accessHr))
            {
                int raw = Convert.ToInt32(
                    access,
                    CultureInfo.InvariantCulture);

                item.AccessRightsRaw = raw;
                item.AccessRightsText =
                    AccessRightsName(raw);
            }
            else if (accessHr < 0)
            {
                errors.Add(
                    "AccessRights=" +
                    HResultText(accessHr));
            }

            if (readCurrentValues)
            {
                object value;
                int valueHr;

                if (TryReadProperty(
                    properties,
                    item.ItemId,
                    2,
                    out value,
                    out valueHr))
                {
                    item.Value = NormalizeDaValue(value);
                    item.ValueType =
                        value == null
                            ? null
                            : value.GetType().FullName;
                    item.ValueStatus = "S_OK";
                }
                else
                {
                    item.ValueStatus =
                        HResultText(valueHr);

                    if (valueHr < 0)
                    {
                        errors.Add(
                            "Value=" +
                            HResultText(valueHr));
                    }
                }

                object quality;
                int qualityHr;

                if (TryReadProperty(
                    properties,
                    item.ItemId,
                    3,
                    out quality,
                    out qualityHr))
                {
                    int raw = Convert.ToInt32(
                        quality,
                        CultureInfo.InvariantCulture);

                    item.QualityRaw = raw;
                    item.Quality = QualityName(raw);
                }
                else if (qualityHr < 0)
                {
                    errors.Add(
                        "Quality=" +
                        HResultText(qualityHr));
                }

                object timestamp;
                int timestampHr;

                if (TryReadProperty(
                    properties,
                    item.ItemId,
                    4,
                    out timestamp,
                    out timestampHr))
                {
                    item.SourceTimestamp =
                        NormalizeDaTimestamp(timestamp);
                }
                else if (timestampHr < 0)
                {
                    errors.Add(
                        "Timestamp=" +
                        HResultText(timestampHr));
                }
            }

            item.PropertyReadError =
                errors.Count == 0
                    ? null
                    : String.Join(
                        "; ",
                        errors.ToArray());

            item.Status =
                errors.Count == 0
                    ? "OK"
                    : "PARTIAL";
        }

        private static bool TryReadProperty(
            IOPCItemProperties properties,
            string itemId,
            int propertyId,
            out object value,
            out int propertyHr)
        {
            value = null;
            propertyHr = unchecked((int)0x80004005);

            IntPtr values = IntPtr.Zero;
            IntPtr errors = IntPtr.Zero;

            try
            {
                properties.GetItemProperties(
                    itemId,
                    1,
                    new int[] { propertyId },
                    out values,
                    out errors);

                if (errors != IntPtr.Zero)
                {
                    propertyHr = Marshal.ReadInt32(errors);
                }
                else
                {
                    propertyHr = 0;
                }

                if (propertyHr < 0 ||
                    values == IntPtr.Zero)
                {
                    return false;
                }

                value =
                    Marshal.GetObjectForNativeVariant(
                        values);

                return true;
            }
            catch (COMException ex)
            {
                propertyHr = ex.ErrorCode;
                return false;
            }
            finally
            {
                if (values != IntPtr.Zero)
                {
                    try
                    {
                        VariantClear(values);
                    }
                    catch
                    {
                    }

                    try
                    {
                        Marshal.FreeCoTaskMem(values);
                    }
                    catch
                    {
                    }
                }

                if (errors != IntPtr.Zero)
                {
                    try
                    {
                        Marshal.FreeCoTaskMem(errors);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private static List<Guid> ReadGuids(
            IOPCEnumGUID enumerator,
            CancellationToken ct)
        {
            List<Guid> result = new List<Guid>();
            IntPtr buffer =
                Marshal.AllocCoTaskMem(
                    Marshal.SizeOf(typeof(Guid)));

            try
            {
                while (true)
                {
                    ct.ThrowIfCancellationRequested();

                    int fetched = 0;
                    enumerator.Next(
                        1,
                        buffer,
                        out fetched);

                    if (fetched <= 0)
                    {
                        break;
                    }

                    Guid value =
                        (Guid)Marshal.PtrToStructure(
                            buffer,
                            typeof(Guid));

                    result.Add(value);
                }
            }
            finally
            {
                Marshal.FreeCoTaskMem(buffer);
            }

            return result;
        }

        private static List<string> ReadStrings(
            IEnumString enumerator,
            CancellationToken ct)
        {
            List<string> result =
                new List<string>();

            IntPtr buffer =
                Marshal.AllocCoTaskMem(
                    IntPtr.Size);

            try
            {
                while (true)
                {
                    ct.ThrowIfCancellationRequested();

                    Marshal.WriteIntPtr(
                        buffer,
                        IntPtr.Zero);

                    int fetched;
                    int hr = enumerator.RemoteNext(
                        1,
                        buffer,
                        out fetched);

                    if (fetched <= 0)
                    {
                        break;
                    }

                    IntPtr stringPointer =
                        Marshal.ReadIntPtr(buffer);

                    try
                    {
                        string value =
                            stringPointer == IntPtr.Zero
                                ? null
                                : Marshal.PtrToStringUni(
                                    stringPointer);

                        if (!String.IsNullOrWhiteSpace(value))
                        {
                            result.Add(value);
                        }
                    }
                    finally
                    {
                        if (stringPointer != IntPtr.Zero)
                        {
                            Marshal.FreeCoTaskMem(
                                stringPointer);
                        }
                    }

                    if (hr != 0 && fetched == 0)
                    {
                        break;
                    }
                }
            }
            finally
            {
                Marshal.FreeCoTaskMem(buffer);
            }

            return result;
        }

        private static string VarTypeName(int vt)
        {
            try
            {
                VarEnum value = (VarEnum)vt;
                return value.ToString();
            }
            catch
            {
                return "VARTYPE(" + vt + ")";
            }
        }

        private static string AccessRightsName(int raw)
        {
            bool read = (raw & 1) != 0;
            bool write = (raw & 2) != 0;

            if (read && write)
            {
                return "Read/Write";
            }

            if (read)
            {
                return "Read";
            }

            if (write)
            {
                return "Write";
            }

            return "None";
        }

        private static string QualityName(int raw)
        {
            int major = raw & 0xC0;

            string state =
                major == 0xC0
                    ? "Good"
                    : major == 0x40
                        ? "Uncertain"
                        : "Bad";

            return state +
                " (0x" +
                raw.ToString(
                    "X4",
                    CultureInfo.InvariantCulture) +
                ")";
        }

        private static object NormalizeDaValue(object value)
        {
            if (value == null)
            {
                return null;
            }

            Type type = value.GetType();

            if (type.IsPrimitive ||
                value is decimal ||
                value is string ||
                value is DateTime ||
                value is DateTimeOffset ||
                value is Guid)
            {
                return value;
            }

            byte[] bytes = value as byte[];
            if (bytes != null)
            {
                return Convert.ToBase64String(bytes);
            }

            Array array = value as Array;
            if (array != null)
            {
                List<object> values =
                    new List<object>();

                int count =
                    Math.Min(
                        array.Length,
                        2048);

                for (int i = 0; i < count; i++)
                {
                    values.Add(
                        NormalizeDaValue(
                            array.GetValue(i)));
                }

                if (array.Length > count)
                {
                    values.Add(
                        "... truncated " +
                        (array.Length - count) +
                        " items");
                }

                return values;
            }

            return Convert.ToString(
                value,
                CultureInfo.InvariantCulture);
        }

        private static DateTimeOffset? NormalizeDaTimestamp(
            object value)
        {
            if (value == null)
            {
                return null;
            }

            if (value is DateTimeOffset)
            {
                return (DateTimeOffset)value;
            }

            if (value is DateTime)
            {
                DateTime dateTime =
                    (DateTime)value;

                if (dateTime.Kind == DateTimeKind.Utc)
                {
                    return new DateTimeOffset(
                        dateTime);
                }

                return new DateTimeOffset(
                    dateTime.ToUniversalTime());
            }

            return null;
        }

        private static string HResultText(int hr)
        {
            return "0x" +
                unchecked((uint)hr).ToString(
                    "X8",
                    CultureInfo.InvariantCulture);
        }

        private static string BuildComDiagnostic(
            COMException ex,
            string host)
        {
            uint code = unchecked((uint)ex.ErrorCode);

            string suffix = "";

            if (code == 0x80070005)
            {
                suffix =
                    "\r\nDCOM вернул Access Denied. Проверьте права Launch/Activation/Access " +
                    "для текущей Windows-учётной записи.";
            }
            else if (code == 0x800706BA)
            {
                suffix =
                    "\r\nRPC Server Unavailable. Проверьте доступность Windows-хоста, " +
                    "firewall, DCOM/RPC и службу OPCEnum.";
            }
            else if (code == 0x80040154)
            {
                suffix =
                    "\r\nClass not registered. OPCEnum/OPC DA Server не зарегистрирован " +
                    "на указанном Windows-хосте либо указан неверный ProgID/CLSID.";
            }
            else if (code == 0x80070721)
            {
                suffix =
                    "\r\nОшибка пакета безопасности DCOM. Проверьте Windows/DCOM hardening, " +
                    "домен/учётную запись и разрешения удалённого OPC.";
            }

            return
                "OPC DA / DCOM ошибка на " +
                host +
                ": " +
                ex.Message +
                "\r\nHRESULT=" +
                HResultText(ex.ErrorCode) +
                suffix;
        }

        private static string NormalizeHost(string host)
        {
            string value =
                (host ?? String.Empty).Trim();

            if (value.Length == 0)
            {
                throw new InvalidOperationException(
                    "Укажите Windows-хост/IP OPC DA Server.");
            }

            if (value.IndexOf(
                "://",
                StringComparison.Ordinal) >= 0)
            {
                throw new InvalidOperationException(
                    "OPC DA использует Windows COM/DCOM. " +
                    "Введите IP/hostname, а не opc.tcp:// URL.");
            }

            return value;
        }

        private static bool IsLocalHost(string host)
        {
            return String.Equals(
                       host,
                       ".",
                       StringComparison.OrdinalIgnoreCase) ||
                   String.Equals(
                       host,
                       "localhost",
                       StringComparison.OrdinalIgnoreCase) ||
                   String.Equals(
                       host,
                       Environment.MachineName,
                       StringComparison.OrdinalIgnoreCase);
        }

        private static void ReleaseCom(object value)
        {
            if (value == null ||
                !Marshal.IsComObject(value))
            {
                return;
            }

            try
            {
                Marshal.FinalReleaseComObject(value);
            }
            catch
            {
            }
        }

        private static void ReportBrowseProgress(
            BrowseResult result,
            IProgress<ScanProgress> progress)
        {
            Report(
                progress,
                "Исследование OPC DA namespace",
                "Найдено Item: " +
                result.Items.Count +
                " · просмотрено ветвей/объектов: " +
                result.BrowsedCount,
                null);
        }

        private static void Report(
            IProgress<ScanProgress> progress,
            string stage,
            string details,
            int? percent)
        {
            if (progress == null)
            {
                return;
            }

            ScanProgress p = new ScanProgress();
            p.Stage = stage;
            p.Details = details;
            p.Percent = percent;
            progress.Report(p);
        }

        private sealed class BrowseResult
        {
            public int BrowsedCount;
            public bool Truncated;
            public List<ResearchItem> Items =
                new List<ResearchItem>();
            public HashSet<string> ItemIds =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);
            public HashSet<string> VisitedBranches =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);
        }
    }

    internal enum OPCNAMESPACETYPE
    {
        OPC_NS_HIERARCHIAL = 1,
        OPC_NS_FLAT = 2
    }

    internal enum OPCBROWSETYPE
    {
        OPC_BRANCH = 1,
        OPC_LEAF = 2,
        OPC_FLAT = 3
    }

    internal enum OPCBROWSEDIRECTION
    {
        OPC_BROWSE_UP = 1,
        OPC_BROWSE_DOWN = 2,
        OPC_BROWSE_TO = 3
    }

    [ComImport]
    [Guid("55C382C8-21C7-4E88-96C1-BECFB1E3F483")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IOPCEnumGUID
    {
        void Next(
            [MarshalAs(UnmanagedType.I4)] int celt,
            IntPtr rgelt,
            [Out][MarshalAs(UnmanagedType.I4)] out int pceltFetched);

        void Skip(
            [MarshalAs(UnmanagedType.I4)] int celt);

        void Reset();

        void Clone(
            [Out] out IOPCEnumGUID ppenum);
    }

    [ComImport]
    [Guid("00000101-0000-0000-C000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IEnumString
    {
        [PreserveSig]
        int RemoteNext(
            [MarshalAs(UnmanagedType.I4)] int celt,
            IntPtr rgelt,
            [Out][MarshalAs(UnmanagedType.I4)] out int pceltFetched);

        void Skip(
            [MarshalAs(UnmanagedType.I4)] int celt);

        void Reset();

        void Clone(
            [Out] out IEnumString ppenum);
    }

    [ComImport]
    [Guid("9DD0B56C-AD9E-43EE-8305-487F3188BF7A")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IOPCServerList2
    {
        void EnumClassesOfCategories(
            [MarshalAs(UnmanagedType.I4)] int cImplemented,
            [MarshalAs(
                UnmanagedType.LPArray,
                ArraySubType = UnmanagedType.LPStruct,
                SizeParamIndex = 0)]
            Guid[] rgcatidImpl,
            [MarshalAs(UnmanagedType.I4)] int cRequired,
            [MarshalAs(
                UnmanagedType.LPArray,
                ArraySubType = UnmanagedType.LPStruct,
                SizeParamIndex = 2)]
            Guid[] rgcatidReq,
            [Out] out IOPCEnumGUID ppenumClsid);

        void GetClassDetails(
            ref Guid clsid,
            [Out][MarshalAs(UnmanagedType.LPWStr)] out string ppszProgID,
            [Out][MarshalAs(UnmanagedType.LPWStr)] out string ppszUserType,
            [Out][MarshalAs(UnmanagedType.LPWStr)] out string ppszVerIndProgID);

        void CLSIDFromProgID(
            [MarshalAs(UnmanagedType.LPWStr)] string szProgId,
            [Out] out Guid clsid);
    }

    [ComImport]
    [Guid("39C13A4F-011E-11D0-9675-0020AFD8ADB3")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IOPCBrowseServerAddressSpace
    {
        void QueryOrganization(
            [Out] out OPCNAMESPACETYPE pNameSpaceType);

        void ChangeBrowsePosition(
            OPCBROWSEDIRECTION dwBrowseDirection,
            [MarshalAs(UnmanagedType.LPWStr)] string szString);

        void BrowseOPCItemIDs(
            OPCBROWSETYPE dwBrowseFilterType,
            [MarshalAs(UnmanagedType.LPWStr)] string szFilterCriteria,
            [MarshalAs(UnmanagedType.I2)] short vtDataTypeFilter,
            [MarshalAs(UnmanagedType.I4)] int dwAccessRightsFilter,
            [Out] out IEnumString ppIEnumString);

        void GetItemID(
            [MarshalAs(UnmanagedType.LPWStr)] string szItemDataID,
            [Out][MarshalAs(UnmanagedType.LPWStr)] out string szItemID);

        void BrowseAccessPaths(
            [MarshalAs(UnmanagedType.LPWStr)] string szItemID,
            [Out] out IEnumString pIEnumString);
    }

    [ComImport]
    [Guid("39C13A72-011E-11D0-9675-0020AFD8ADB3")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IOPCItemProperties
    {
        void QueryAvailableProperties(
            [MarshalAs(UnmanagedType.LPWStr)] string szItemID,
            [Out][MarshalAs(UnmanagedType.I4)] out int pdwCount,
            [Out] out IntPtr ppPropertyIDs,
            [Out] out IntPtr ppDescriptions,
            [Out] out IntPtr ppvtDataTypes);

        void GetItemProperties(
            [MarshalAs(UnmanagedType.LPWStr)] string szItemID,
            [MarshalAs(UnmanagedType.I4)] int dwCount,
            [MarshalAs(
                UnmanagedType.LPArray,
                ArraySubType = UnmanagedType.I4,
                SizeParamIndex = 1)]
            int[] pdwPropertyIDs,
            [Out] out IntPtr ppvData,
            [Out] out IntPtr ppErrors);

        void LookupItemIDs(
            [MarshalAs(UnmanagedType.LPWStr)] string szItemID,
            [MarshalAs(UnmanagedType.I4)] int dwCount,
            [MarshalAs(
                UnmanagedType.LPArray,
                ArraySubType = UnmanagedType.I4,
                SizeParamIndex = 1)]
            int[] pdwPropertyIDs,
            [Out] out IntPtr ppszNewItemIDs,
            [Out] out IntPtr ppErrors);
    }

    internal sealed class ScanOptions
    {
        public string Endpoint;
        public int SecurityMode;
        public bool Anonymous;
        public string Username;
        public string Password;
        public bool ReadCurrentValues;
        public string PkiDirectory;
    }

    internal sealed class ScanProgress
    {
        public string Stage { get; set; }
        public string Details { get; set; }
        public int? Percent { get; set; }
    }

    internal sealed class ResearchResult
    {
        public string Contract { get; set; }
        public string Protocol { get; set; }
        public string BasedOnLocalAppContract { get; set; }
        public string Mode { get; set; }
        public string EndpointInput { get; set; }
        public string EndpointUrl { get; set; }
        public string SelectedEndpointUrl { get; set; }
        public string SecurityMode { get; set; }
        public string SecurityPolicyUri { get; set; }
        public string Authentication { get; set; }

        public string Host { get; set; }
        public string ProgId { get; set; }
        public string Clsid { get; set; }
        public string ServerUserType { get; set; }
        public List<string> OpcDaVersions { get; set; }

        public DateTimeOffset StartedAtUtc { get; set; }
        public DateTimeOffset CompletedAtUtc { get; set; }
        public int BrowsedNodeCount { get; set; }
        public int VariableCount { get; set; }
        public bool Truncated { get; set; }
        public bool ReadCurrentValues { get; set; }
        public ServerInfo Server { get; set; }
        public List<NamespaceInfo> Namespaces { get; set; }
        public List<ResearchItem> Items { get; set; }
    }

    internal sealed class ServerInfo
    {
        public string ApplicationName { get; set; }
        public string ApplicationUri { get; set; }
        public string ProductUri { get; set; }
        public string ApplicationType { get; set; }

        public string Host { get; set; }
        public string ProgId { get; set; }
        public string Clsid { get; set; }
    }

    internal sealed class NamespaceInfo
    {
        public int Index { get; set; }
        public string Uri { get; set; }
    }

    internal sealed class ResearchItem
    {
        public string Protocol { get; set; }
        public string ItemId { get; set; }
        public string NodeId { get; set; }
        public ushort NamespaceIndex { get; set; }
        public string NamespaceUri { get; set; }
        public string BrowsePath { get; set; }
        public string BrowseName { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public string NodeClass { get; set; }
        public string TypeDefinitionId { get; set; }
        public string DataTypeNodeId { get; set; }
        public string DataTypeName { get; set; }
        public int? ValueRank { get; set; }
        public string ArrayDimensions { get; set; }
        public byte? AccessLevel { get; set; }
        public byte? UserAccessLevel { get; set; }
        public bool? Historizing { get; set; }
        public double? MinimumSamplingInterval { get; set; }
        public string Status { get; set; }
        public string Error { get; set; }

        public object Value { get; set; }
        public string ValueType { get; set; }
        public string ValueStatus { get; set; }
        public string Quality { get; set; }
        public int? QualityRaw { get; set; }
        public string AccessRightsText { get; set; }
        public int? AccessRightsRaw { get; set; }
        public string PropertyReadError { get; set; }
        public DateTimeOffset? SourceTimestamp { get; set; }
        public DateTimeOffset? ServerTimestamp { get; set; }
    }
}
