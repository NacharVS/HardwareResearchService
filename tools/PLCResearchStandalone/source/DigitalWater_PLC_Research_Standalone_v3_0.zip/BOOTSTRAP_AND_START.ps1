﻿param(
    [switch]$ForceBuild
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Tools = Join-Path $Root ".tools"
$DotnetDir = Join-Path $Root ".dotnet"
$InstallScript = Join-Path $Tools "dotnet-install.ps1"
$Project = Join-Path $Root "src\DigitalWater.PLCResearch.csproj"
$AppDir = Join-Path $Root "app"
$Exe = Join-Path $AppDir "DigitalWater.PLCResearch.exe"

$env:DOTNET_CLI_TELEMETRY_OPTOUT = "1"
$env:DOTNET_NOLOGO = "1"
$env:NUGET_XMLDOC_MODE = "skip"

function Step([string]$Text) {
    Write-Host ""
    Write-Host ("==> " + $Text) -ForegroundColor Cyan
}

function Get-RuntimeIdentifier {
    $arch = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) {
        $arch = $env:PROCESSOR_ARCHITEW6432
    }

    switch -Regex ($arch) {
        "ARM64" { return "win-arm64" }
        "AMD64|x86_64" { return "win-x64" }
        default { return "win-x86" }
    }
}

function Ensure-DotnetSdk {
    New-Item -ItemType Directory -Force -Path $Tools, $DotnetDir | Out-Null
    $dotnet = Join-Path $DotnetDir "dotnet.exe"

    if (Test-Path -LiteralPath $dotnet) {
        try {
            $version = & $dotnet --version
            if ($LASTEXITCODE -eq 0 -and $version -match '^10\.') {
                Write-Host "Portable .NET SDK already prepared: $version"
                return $dotnet
            }
        } catch {}
    }

    Step "Download official Microsoft dotnet-install script"
    Invoke-WebRequest `
        -UseBasicParsing `
        -Uri "https://dot.net/v1/dotnet-install.ps1" `
        -OutFile $InstallScript

    Step "Install portable .NET 10 SDK into this folder"
    & powershell.exe `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -File $InstallScript `
        -Channel "10.0" `
        -Quality "GA" `
        -InstallDir $DotnetDir `
        -NoPath |
        ForEach-Object { Write-Host $_ }

    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $dotnet)) {
        throw "Portable .NET 10 SDK installation failed."
    }

    $version = & $dotnet --version
    Write-Host "Portable .NET SDK ready: $version"
    return $dotnet
}

function Build-StandaloneApp([string]$Dotnet) {
    $rid = Get-RuntimeIdentifier

    Step ("Restore dependencies for " + $rid)
    & $Dotnet restore $Project `
        -r $rid `
        --nologo `
        --verbosity minimal

    if ($LASTEXITCODE -ne 0) {
        throw "dotnet restore failed."
    }

    Step ("Publish self-contained application for " + $rid)

    if (Test-Path -LiteralPath $AppDir) {
        Remove-Item -LiteralPath $AppDir -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $AppDir | Out-Null

    & $Dotnet publish $Project `
        -c Release `
        -r $rid `
        --self-contained true `
        --no-restore `
        -p:PublishSingleFile=false `
        -p:DebugType=None `
        -p:DebugSymbols=false `
        -o $AppDir `
        --nologo `
        --verbosity minimal

    if ($LASTEXITCODE -ne 0) {
        throw "dotnet publish failed."
    }

    if (-not (Test-Path -LiteralPath $Exe)) {
        throw "Build completed without DigitalWater.PLCResearch.exe."
    }

    Write-Host ""
    Write-Host "BUILD=PASS" -ForegroundColor Green
    Write-Host ("APP=" + $Exe) -ForegroundColor Green
    Write-Host "The app is now self-contained and can be used offline." -ForegroundColor Green
}

try {
    Write-Host "DigitalWater PLC Research Standalone v3.0" -ForegroundColor Green
    Write-Host "DIRECT OPC UA + OPC DA. LocalApp is NOT used." -ForegroundColor Green

    if ($ForceBuild -or -not (Test-Path -LiteralPath $Exe)) {
        Write-Host ""
        Write-Host "First preparation requires Internet." -ForegroundColor Yellow
        Write-Host "Microsoft .NET SDK and OPC Foundation libraries will be downloaded only for this local build." -ForegroundColor Yellow

        $dotnet = [string](Ensure-DotnetSdk | Select-Object -Last 1)
        if (-not (Test-Path -LiteralPath $dotnet)) {
            throw "Portable dotnet executable path is invalid: $dotnet"
        }
        Build-StandaloneApp $dotnet
    }

    Step "Start standalone PLC Research"
    Start-Process -FilePath $Exe -WorkingDirectory $AppDir
    exit 0
}
catch {
    Write-Host ""
    Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host ""
    Write-Host "No PLC write operation was executed." -ForegroundColor Yellow
    Write-Host "If this is a build error, copy the complete console output and send it back." -ForegroundColor Yellow
    exit 1
}
