@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BOOTSTRAP_AND_START.ps1" -ForceBuild
if errorlevel 1 (
  echo.
  echo Rebuild ended with an error.
  pause
)
endlocal
