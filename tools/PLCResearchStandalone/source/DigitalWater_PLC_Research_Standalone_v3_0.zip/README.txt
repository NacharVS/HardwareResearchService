DigitalWater PLC Research Standalone v3.0
=========================================

Что изменено
------------
Теперь одна автономная утилита исследует два протокола:

1. OPC UA
2. OPC DA (Classic COM/DCOM)

LocalApp НЕ нужен.
GlobalHub НЕ нужен.
Docker НЕ нужен.

OPC UA
------
Пользователь вводит:
  192.168.1.20
или:
  opc.tcp://192.168.1.20:4840

Утилита напрямую делает OPC UA discovery/session/Browse/Read и сохраняет JSON.

Также исправлено поведение собственного UA-сертификата:
если именно локальный сертификат приложения pki\own стал невалидным,
утилита пересоздаёт только его и повторяет проверку.

OPC DA
------
OPC DA — это Windows COM/DCOM.

В режиме OPC DA пользователь вводит IP или hostname Windows-компьютера,
на котором работает OPC DA Server, например:

  192.168.1.50
  SCADA-PC

НЕ нужно писать opc.tcp:// — это только OPC UA.

Дальше:
1. Нажать «Найти DA-серверы».
2. Утилита обращается к OPCEnum на указанном Windows-хосте.
3. Находит зарегистрированные DA1 / DA2 / DA3 серверы.
4. Пользователь выбирает ProgID.
5. «Исследовать OPC DA и сохранить JSON».

Если OPCEnum недоступен, но ProgID или CLSID известен, его можно ввести вручную.

Что получает OPC DA research
-----------------------------
- Host
- ProgID
- CLSID (когда известен)
- DA1 / DA2 / DA3 category
- ItemID
- BrowsePath
- BrowseName
- canonical VARTYPE (если IOPCItemProperties доступен)
- Access Rights
- Value (опционально)
- Quality (опционально)
- Timestamp (опционально)
- ошибки чтения отдельных свойств

READ ONLY
---------
OPC UA:
- Discovery
- Browse
- Read

OPC DA:
- OPCEnum discovery
- Browse
- GetItemProperties

В приложении нет OPC UA Write.
В приложении нет OPC DA Write.
Управляющие команды не реализованы.

Важное отличие OPC DA
---------------------
OPC DA обычно является Windows OPC Server, а не сетевым endpoint вида
opc.tcp://IP:PORT.

Для удалённого OPC DA Windows-хоста обычно должны быть правильно настроены:
- OPCEnum / OPC Core Components;
- DCOM;
- Windows Firewall / RPC;
- Launch / Activation / Access permissions;
- учётная запись Windows.

v3.0 использует текущую Windows-учётную запись пользователя.
Для DCOM включается packet integrity, что соответствует современному
Windows DCOM hardening.

Совместимость OPC DA
--------------------
Текущий browse-адаптер реализует классический интерфейс
IOPCBrowseServerAddressSpace (OPC DA 1.0/2.05a).

DA3-серверы обнаруживаются через OPCEnum. Если DA3-сервер также предоставляет
классический совместимый browse-интерфейс — он исследуется.

Если конкретный сервер является "DA3-only" и не предоставляет
IOPCBrowseServerAddressSpace, v3.0 выдаст понятную ошибку. Для такого сервера
потребуется добавить отдельный IOPCBrowse (DA3) адаптер.

Первый запуск
-------------
Как и v2.3, первый запуск:
- скачивает portable .NET 10 SDK;
- восстанавливает официальный OPC Foundation OPC UA package;
- собирает self-contained Windows приложение.

OPC DA реализован через встроенный Windows COM/DCOM и не требует отдельной
сторонней программы.

После успешной сборки приложение можно использовать офлайн в локальной сети.

Запуск
------
  START_STANDALONE.bat

Принудительная пересборка:
  REBUILD_STANDALONE.bat
